# Pizzas_ditributed_DB_web_app
This web app was made for visualizing the information about pizzas storaged in several clusters that has been taken from a CSV file. This project uses javascript, python and html.
